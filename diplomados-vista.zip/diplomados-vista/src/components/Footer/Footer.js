import React from "react";
import {
Box,
Container
} from "./FooterStyles";

const Footer = () => {
return (
	<Box>
	<h1 style={{ color: "white",
				textAlign: "center",
				marginTop: "-50px" }}>
		Página de diplomados 
	</h1>
	<Container>

	</Container>
	</Box>
);
};
export default Footer;

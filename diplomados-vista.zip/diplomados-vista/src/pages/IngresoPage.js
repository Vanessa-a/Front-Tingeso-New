import React,{Component} from 'react';
import '../components/Ingreso/Ingreso.css'
import {Button,Form,Col,Row,Card} from 'react-bootstrap'

class InicioSesion extends Component {
    state ={
        email : '',
        password: ''
    }
    handleChange = (e) => {
        this.setState({
            [e.target.id]: e.target.value
        })
    }
    handleSubmmit = (e) => {
        e.preventDefault();
        console.log(this.state);
    }
    render(){
        return(
            <div className="container d-flex justify-content-center">
            <Card style={{ width: '45rem', top: '2rem', display: 'flex', justifyContent: 'center', borderColor: 'transparent' }}>
                <Form>
                    <Form.Group as={Row} className="mb-3" controlId="formPlaintextEmail">
                        <Form.Label column sm="2">
                        Email
                        </Form.Label>
                        <Col sm="10">
                        <Form.Control defaultValue="email@example.com" />
                        </Col>
                    </Form.Group>

                    <Form.Group as={Row} className="mb-3" controlId="formPlaintextPassword">
                        <Form.Label column sm="2">
                        Password
                        </Form.Label>
                        <Col sm="10">
                        <Form.Control type="password" placeholder="Password" />
                        </Col>
                    </Form.Group>
                    <div className="input-field">
                        <Button variant="primary">Iniciar</Button>{' '}
                    </div>
                </Form>
            </Card>
            </div>
        )
    }
}

export default InicioSesion
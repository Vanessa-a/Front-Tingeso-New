exec java -jar -Dserver.port=3000 build/libs/Privat-Service-0.0.1-SNAPSHOT.jar

package com.G3Tingeso.PrivateServices.controller;

import java.sql.Date;
import java.time.Instant;
import java.util.HashMap;

import javax.crypto.SecretKey;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@RestController
public class JwtController {
    @GetMapping("/generate-token")
    @ResponseBody
    public String GenerateToken() {
        try{
            //-------------------------------------------------------------------------------
            //HEADER
            //-------------------------------------------------------------------------------
            //The JWT signature algorithm we will be using to sign the token
            SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.ES256;
            SecretKey key = Keys.secretKeyFor(SignatureAlgorithm.HS256);
            //Creating the Header of
            HashMap<String, Object> header = new HashMap<String,Object>();
            header.put("alg", signatureAlgorithm.toString()); //HS256
            header.put("typ","JWT");
            //-------------------------------------------------------------------------------
            //CREATING TOKEN + ADDING HEADER
            //-------------------------------------------------------------------------------
            //Generate tokenJWT + adding header
            JwtBuilder tokenJWT = Jwts
                    .builder()
                    .setHeader(header)
                    .setIssuer("http://trustyapp.com/")
                    .setId("1")
                    .setSubject("www.javadesde0.com")
                    .claim("name", "David Bernal")
                    .claim("scope", "admins")
                    // Fri Jun 24 2016 15:33:42 GMT-0400 (EDT)
                    .setIssuedAt(Date.from(Instant.ofEpochSecond(1466796822L)))
                    // Sat Jun 24 2116 15:33:42 GMT-0400 (EDT)
                    .setExpiration(Date.from(Instant.ofEpochSecond(4622470422L))).signWith(key);
            //-------------------------------------------------------------------------------
            //CREATING TOKEN + ADDING HEADER
            //-------------------------------------------------------------------------------
            //Compact the tokenJWT + save the value in tokenJWTString
            String tokenJWTString = tokenJWT.compact();
            System.out.println(tokenJWTString);
            //Response to Request from Controller
            return tokenJWTString;
        }catch (Exception e) {
            System.out.println(e);
            return "Error creating the token JWT" + e;
        }
    }
}

package com.G3Tingeso.PrivateServices.models;

public class Docente_titulo {
    private int id;
    private int id_docente;
    private int id_titulo;
    

    /**
     * @return int return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return int return the id_docente
     */
    public int getId_docente() {
        return id_docente;
    }

    /**
     * @param id_docente the id_docente to set
     */
    public void setId_docente(int id_docente) {
        this.id_docente = id_docente;
    }

    /**
     * @return int return the id_titulo
     */
    public int getId_titulo() {
        return id_titulo;
    }

    /**
     * @param id_titulo the id_titulo to set
     */
    public void setId_titulo(int id_titulo) {
        this.id_titulo = id_titulo;
    }

}
